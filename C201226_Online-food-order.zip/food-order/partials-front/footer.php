<!-- SOcial Section Starts Here-->
<section class="Social ">
    <div class= "Container text-center">
        <ul>
            <li>
                <a href="#"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
            </li>
            <li>
                <a href="#"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
            </li>
            <li>
                <a href="#"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
            </li>
        </ul>
        </div>
</section>
<!--SOcial Section Ends Here-->

<!-- FOOter Section Starts Here-->
<section class="footer ">
    <div class= "Container text-center">
        <p>All Rights Reserved. Designed By <a href="#">Dipa Dey</a></p>
        </div>
</section>
<!--FOOter Section Ends Here-->

</body>
</html>