<?php

//include constant.php file here
include('../config/constants.php');
//1.get the id of admin to be deleted
echo $ID = $_GET['ID'];

//2.Create sql query to delete admin
$sql = "DELETE FROM tbl_admin WHERE ID=$ID";


//Execute the query
$res = mysqli_query($conn ,$sql);

//check weather the query executed successfully or not
if($res == true)
{
    //query executed successfully and admin deleted
    //echo"Admin Deleted";
    $_SESSION['delete'] = "<div class ='success'>Admin deleted Successfully.</div>";
    header('location:'.SITEURL.'admin/manage-admin.php');
}
else
{
//failed to dekete admin
//echo "Failed to Delete Admin";
$_SESSION['delete'] = "<div class = 'error'>Failed to delete Admin.Try Again Later.</div>";
header('location:'.SITEURL.'admin/manage-admin.php');
}

//3. redirect to manage admin page with message (success/error)


?>