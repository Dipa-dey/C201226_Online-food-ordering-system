<?php include('partials/menu.php'); ?>   

<div class="main-content">
<div class="wrapper">
    <h1>Change Password</h1>

    <?php
    if(isset($_GET['ID']))//checking whether the session is set or not
    {
         $ID = $_GET['ID'] ; //display the session massage if set
    }
    ?>

    <form action=""method="POST">
    <table class="tbl-30">
        <tr>
            <td>Current Password : </td>
            <td>
                <input type="Password" name="current_Password"placeholder="Current Password">
            </td>
        </tr>

        <tr>
            <td>New Password : </td>
            <td>
               <input type="Password" name="new_Password"placeholder="New Password">
            </td>
        </tr>

        <tr>
            <td>Confirm Password : </td>
            <td>
               <input type="Password" name="confirm_Password"placeholder="Confirm Password">
            </td>
        </tr>

        <tr>
            <td colspan="2" >
            <input type = "hidden" name="ID"value="<?php echo $ID;?>">
                <input type="submit"name="submit"value="Change Password" class = "btn-secondary">
</td>
        </tr>
    </table>
    </form>

</div>
</div> 
<?php
         if(isset($_POST['submit']))
         {
            //echo"Clicked";
            $ID=$_POST['ID'];
            $current_Password =md5( $_POST['current_Password']);
            $new_Password =md5( $_POST['new_Password']);
            $confirm_Password =md5( $_POST['confirm_Password']);

            $sql = "SELECT * FROM tbl_admin WHERE ID = $ID AND Password = '$current_Password'";

            $res = mysqli_query($conn ,$sql);

            if($res==true)
            {
               $count = mysqli_num_rows($res);

               if($count==1)
               {
                   //echo "User Found";
                   if($new_Password==$confirm_Password)
                   {
                    $sql2="UPDATE tbl_admin SET
                    Password='$new_Password'
                    WHERE ID=$ID
                     ";

                     $res2 = mysqli_query($conn,$sql2);
                     if($res2==true)
                     {
                        $_SESSION['change-pwd']= "<div class = 'success'>Password Changed Successfully.</div>";
                        header('location:'.SITEURL.'admin/manage-admin.php');
                     }
                     else
                     {
                        $_SESSION['change-pwd']= "<div class = 'error'>Failed to Change Password.</div>";
                        header('location:'.SITEURL.'admin/manage-admin.php');
                     }

                   }
                   else
                   {
                    $_SESSION['pwd-not-match']= "<div class = 'error'>Password did not match.</div>";
                    header('location:'.SITEURL.'admin/manage-admin.php');
                   }
               }
               else
               {
                  $_SESSION['user-not-found']= "<div class = 'error'>User Not Found.</div>";
                  header('location:'.SITEURL.'admin/manage-admin.php');
               }
            }

         }
?>

<?php include('partials/footer.php'); ?>    